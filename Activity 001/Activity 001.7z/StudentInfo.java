/**
* Activity 1. 
* Tyler Andrews
* 08/28/2017
*/
public class StudentInfo {
/** Prints my name and any previous computer courses.
@param args Command line arguments - not used.
*/
   public static void main(String[] args)
   {
      System.out.println("Name: Tyler Andrews");
      System.out.println("Previous Computer Courses:");
      System.out.println("Regular Computer Science");
   }
}